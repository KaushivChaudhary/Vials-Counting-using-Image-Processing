import os
import cv2
import torch
from ultralytics import YOLO

# Model file path
model_path = r"C:\Users\kaushiv chaudhary\OneDrive\Desktop\Project docs\Vials_counting_600epoc_yolov8n_run_folder (1)\detect\train\weights\best.pt"

# Check if the model file exists
if not os.path.exists(model_path):
    raise FileNotFoundError(f"Model file not found at {model_path}")

print(f"Loading model from {model_path}")

# Load the YOLOv8 model
model = YOLO(model_path)

# Video file path
video_path = r"C:\Users\kaushiv chaudhary\Downloads\VID_20240618_165732.mp4"

# Check if the video file exists
if not os.path.exists(video_path):
    raise FileNotFoundError(f"Video file not found at {video_path}")

print(f"Processing video from {video_path}")

# Output video file path
output_path = r"C:\Users\kaushiv chaudhary\Downloads\Output_video\Output_video_vials.mp4"  # Add a valid video file extension

# Ensure the output directory exists
os.makedirs(os.path.dirname(output_path), exist_ok=True)

# Open the video file
cap = cv2.VideoCapture(video_path)

# Get video properties
fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # Video codec
fps = int(cap.get(cv2.CAP_PROP_FPS))  # Frames per second
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))  # Frame width
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))  # Frame height

# Define the codec and create VideoWriter object
out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

# Variables to count vials and syringes
total_syringes = 0
total_vials = 0

# Function for non-maximum suppression
def nms(detections, iou_thresh=0.6):
    if len(detections) == 0:
        return []

    boxes = [det.xyxy[0] for det in detections]
    scores = [det.conf for det in detections]
    indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)

    keep = []
    while indices:
        current = indices.pop(0)
        keep.append(current)
        remove_indices = []
        for i in indices:
            iou = compute_iou(boxes[current], boxes[i])
            if iou > iou_thresh:
                remove_indices.append(i)
        indices = [i for i in indices if i not in remove_indices]

    return [detections[i] for i in keep]

def compute_iou(box1, box2):
    x1, y1, x2, y2 = box1
    x1_, y1_, x2_, y2_ = box2

    xi1 = max(x1, x1_)
    yi1 = max(y1, y1_)
    xi2 = min(x2, x2_)
    yi2 = min(y2, y2_)
    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)

    box1_area = (x2 - x1) * (y2 - y1)
    box2_area = (x2_ - x1_) * (y2_ - y1_)
    union_area = box1_area + box2_area - inter_area

    return inter_area / union_area

# Process each frame
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Perform detection
    results = model(frame)

    # Extract detections
    detections = results[0].boxes if hasattr(results[0], 'boxes') else results[0]

    # Apply NMS
    detections = nms(detections)

    # Counters for the current frame
    frame_syringes = 0
    frame_vials = 0

    # Loop through detections
    for detection in detections:
        box = detection.xyxy[0]  # Bounding box coordinates
        conf = detection.conf  # Confidence score
        cls = int(detection.cls)  # Class label

        if cls == 0:  # Assuming class 0 is syringes
            frame_vials += 1
        elif cls == 1:  # Assuming class 1 is vials
            frame_syringes += 1

    # Only draw detections if there is only one type in the frame
    if frame_vials > 0 and frame_syringes == 0:
        for detection in detections:
            box = detection.xyxy[0]  # Bounding box coordinates
            conf = detection.conf  # Confidence score
            cls = int(detection.cls)  # Class label

            if cls == 0:  # Syringe
                label = 'vials'
                color = (0, 0, 255)
                cv2.rectangle(frame, (int(box[0]), int(box[1])), (int(box[2]), int(box[3])), color, 2)
                cv2.putText(frame, label, (int(box[0]), int(box[1])-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    elif frame_syringes > 0 and frame_vials == 0:
        for detection in detections:
            box = detection.xyxy[0]  # Bounding box coordinates
            conf = detection.conf  # Confidence score
            cls = int(detection.cls)  # Class label

            if cls == 1:  # Vial
                label = 'syringes'
                color = (0, 255, 0)
                cv2.rectangle(frame, (int(box[0]), int(box[1])), (int(box[2]), int(box[3])), color, 2)
                cv2.putText(frame, label, (int(box[0]), int(box[1])-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

    # Update total counts
    total_syringes += frame_syringes
    total_vials += frame_vials

    # Show total counts on the frame
    text = f'Total syringes: {total_syringes}, Total vials: {total_vials}'
    cv2.putText(frame, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    # Write the frame to the output video
    out.write(frame)

# Release the video capture and writer objects
cap.release()
out.release()

print(f'Total vials detected: {total_vials}')
print(f'Total syringes detected: {total_syringes}')
